var personArray = [];
for (var i=1;i<=75;i++){
    personArray.push({
        id: i,
        // image: `img/${i}.jpg`,
        // thumb_image: `img/${i}.jpg`,
        image: "img/nz.jpg",
        thumb_image: "img/nz.jpg",
        name: i
    })
}